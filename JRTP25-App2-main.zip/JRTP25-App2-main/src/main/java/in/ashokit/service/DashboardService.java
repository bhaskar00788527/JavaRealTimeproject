package in.ashokit.service;

public interface DashboardService {

	public String getQuote();
}
