package in.ashokit.constants;

public class AppConstants {

}
