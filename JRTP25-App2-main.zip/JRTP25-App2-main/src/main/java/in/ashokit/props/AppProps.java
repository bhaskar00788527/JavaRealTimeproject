package in.ashokit.props;

public class AppProps {

}
